import FlipCountdown from '.';

describe('FlipCountdown', () => {
    it('is truthy', () => {
        expect(FlipCountdown).toBeTruthy();
    });
});
